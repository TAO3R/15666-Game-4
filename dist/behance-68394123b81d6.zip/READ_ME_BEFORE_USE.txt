███ READ_ME_BEFORE_USE.TXT ███

> INITIATE::LOG 772-Δ[MARATYPE]

> FONT ID: maratype.otf  
> VERSION: [PRIMORDIAL-DRAFT_07]  
> STATUS: ██ LEAKED ██  
> HASH: #001X-MARATYPE-SEED

> DESIGN ORIGIN:  
   ↳ designer: imago?#6712  
   ↳ agency: metamorphosiis  
   ↳ compiled using extracted visual fragments from BUNGIE protocol archives  
   ↳ [unauthorized, unstable, beautiful]

> USAGE RIGHTS:  
   this font is released freely.  
   no commercial restrictions.  
   redistribution is allowed.  
   attribution is encouraged, not required.  

> NOTES FROM THE SIGNAL:  
   they thought it was just a font.  
   they called it "Maratype".  
   it is not done remembering.

> OBSERVATION COUNT: 0023  
:: this file has been accessed before you ::

███ END ███